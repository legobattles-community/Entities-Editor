print("\n------------------------------------------------------------------------------");
print("Murgalua version identifier : " .. murgaLua_Version);
print("------------------------------------------------------------------------------");
print("Path to murgaLua executable : \n" .. murgaLua_ExePath);
print("------------------------------------------------------------------------------");
print("Murgalua version information : \n\n" .. murgaLua_About);
print("------------------------------------------------------------------------------");
